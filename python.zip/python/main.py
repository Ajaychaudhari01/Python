from PIL import Image,ImageDraw,ImageFont
img = Image.open('ajay.jpg')
d =ImageDraw.Draw(img)
fnt = ImageFont.truetype('freefont/FreeSerifBold.ttf',25)
d.text((60,60),'Ajay Chaudhari',font=fnt, fill=(255,0,0))
d.text((100,160),'AaryaBabu',font=fnt, fill=(255,250,0))

img.save('ajay1.jpg')