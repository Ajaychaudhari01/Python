-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 17, 2023 at 04:02 PM
-- Server version: 8.0.32-0ubuntu0.20.04.2
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_pharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `rating` tinyint UNSIGNED NOT NULL,
  `ip_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `user_id`, `product_id`, `content`, `status`, `rating`, `ip_address`, `created_at`, `updated_at`) VALUES
(1, 1, 23, 'Et velit nihil unde in. Nam saepe cum optio provident. Ratione possimus et ea alias. Quasi numquam ipsa rerum aut nostrum. Minus rerum voluptatum aut.', 1, 5, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(2, 1, 24, 'Omnis eos non neque. Dolorem sed distinctio soluta voluptatibus exercitationem. Quasi vel nemo et incidunt facilis.', 0, 1, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(3, 1, 26, 'Et blanditiis illo voluptatem dolorum officia quod. Vitae libero non vel perspiciatis ea. Aut sapiente corrupti sunt perferendis eaque aut voluptates. Dolorum facilis aliquam sed id nisi. Et id non et molestias quia cupiditate ea porro.', 0, 1, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(4, 1, 26, 'Vitae necessitatibus et soluta mollitia. Doloribus voluptatem et atque ipsa. Ut nisi dolores assumenda sed modi ipsa eaque. Tenetur ab quod qui iusto.', 0, 2, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(5, 64, 8, 'Laudantium sint rem qui ducimus perferendis. Soluta aliquid officiis eum et corporis. Quia est consequuntur sint expedita atque tempore. Dolorem quia sapiente non voluptas et quod.', 0, 4, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(6, 92, 10, 'Sit laudantium omnis praesentium suscipit sint adipisci. Beatae recusandae suscipit cupiditate dolor. Non veniam nobis illum libero a exercitationem. Omnis blanditiis quidem aliquid fugit itaque sed.', 0, 5, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(7, 1, 22, 'Illum numquam enim et nihil consectetur est sunt. Velit nam magnam est. Nemo possimus veritatis molestias tenetur voluptatem quia.', 1, 1, 3, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(8, 103, 11, 'Quas ipsum itaque culpa deserunt fugit accusamus. Distinctio sed ut aut quis eos fugiat ut. Repellat cum eveniet sit velit consequatur. Perspiciatis veniam perspiciatis amet iste.', 0, 4, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(9, 1, 12, 'Quis voluptatem dolorum sint et sunt aut eum. Omnis tempore tenetur quaerat consectetur eum enim. Voluptatem quia molestias excepturi.', 1, 3, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(10, 63, 12, 'Sed aut dolore soluta. Qui nostrum ratione exercitationem neque consequatur ut. In nobis sapiente eum in sed pariatur aliquid.', 1, 2, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(11, 92, 13, 'Veniam iure amet nobis accusamus optio. At itaque perspiciatis veritatis esse quod autem ad. Tempore commodi unde sint non excepturi rerum eos. Et et sapiente sint qui sit voluptas.', 1, 1, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(12, 28, 15, 'Ipsum animi ex est tenetur pariatur quaerat vel. Non deserunt dolorem explicabo error repellendus. Sapiente enim unde nihil consequuntur. Autem soluta eveniet optio nihil.', 1, 1, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(13, 96, 15, 'Odio quod illum odio sed ut omnis error. Voluptates voluptate porro tempore autem dignissimos suscipit sed error. Non cum est voluptatum cupiditate quia et. Ut cum quod a repudiandae itaque necessitatibus voluptas.', 1, 1, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(14, 48, 16, 'Eum excepturi est natus. Dignissimos repudiandae commodi fugiat magni repellendus eligendi. Ipsum earum laboriosam laborum dolorum nostrum. Qui ducimus omnis voluptas saepe et sed. Quasi suscipit quos quibusdam eligendi rem.', 0, 1, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(15, 17, 18, 'Eum repellat dolorem architecto sint quas aut eos. Libero inventore et alias consectetur nihil qui odit.', 1, 5, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46'),
(16, 98, 19, 'Natus quas sed rerum cumque. Sed ea eum vero rem eveniet quia architecto. Ratione temporibus nesciunt aliquid aut.', 0, 4, NULL, '2023-04-13 01:25:46', '2023-04-13 01:25:46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reviews_user_id_foreign` (`user_id`),
  ADD KEY `reviews_product_id_foreign` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
